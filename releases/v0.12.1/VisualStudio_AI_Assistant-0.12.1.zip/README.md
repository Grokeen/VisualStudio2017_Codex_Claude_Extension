# Visual Studio AI Assistant 0.12.1 미리보기

Visual Studio 2017·2019·2022에서 Claude와 Codex를 사용합니다. 실행 중에도 다음 요청을 입력하고 전송할 수 있으며 CLI는 요청을 순서대로 실행합니다. 수정안은 명시적으로 승인하거나 건너뛸 수 있습니다.

오프라인 설치에는 `VisualStudio_AI_Assistant-0.12.1-Preview1-FullOffline-win-x64.zip`을 사용하세요. 작은 `VisualStudio_AI_Assistant-0.12.1.zip`에는 CLI가 없습니다. 완성 묶음은 Codex 0.163.0과 Claude 2.1.302의 Windows x64 런타임을 포함합니다. 로그인과 AI 사용 시에는 허용된 인터넷 연결이 필요합니다.

1. ZIP 전체를 압축 해제하고 모든 Visual Studio 창을 닫습니다.
2. `VerifyOfflineSetup.bat`을 실행하여 표시된 설치 대상을 선택합니다.
3. VS2017 15.7·15.8은 `VS2017.15.7.AIAssistant-0.12.1.vsix`, 15.9 이상은 `VS2017.AIAssistant-0.12.1.vsix`를 사용합니다. VS2019·2022는 해당 연도 파일을 사용합니다.
4. 설치 후 Visual Studio의 **도구 → AI Assistant**를 엽니다.
5. 같은 폴더의 PDF와 `OFFLINE_INSTALL.md`에서 로그인·모드·연속 요청·파일 만들기·테마 설치 절차를 확인합니다.

실행 한 개와 대기 최대 여덟 개를 지원합니다. 대기는 메모리 상태이며 재시작 후 자동 실행하지 않습니다. 적용되지 않은 수정안이 있으면 후속 실행이 멈춥니다. **현재 수정안 건너뛰기**는 소스를 바꾸지 않고 다음 요청을 실행합니다. 승인·적용 후 원본이 달라진 기존 대기 요청은 안전 확인에서 중단될 수 있으므로 다시 제출하세요.

AI 답변에서 마우스 오른쪽 버튼을 눌러 답변 전체 또는 하나의 코드 블록을 새 MD/TXT/HTML/DOCX/코드 파일로 저장할 수 있습니다. 기존 파일은 덮어쓰지 않습니다. DOCX는 실제 문서 형식이며 원문 중심으로 저장됩니다. PDF/XLSX 자동 생성은 지원하지 않습니다.

설정의 **화면 → Visual Studio 전체 테마**에서 Kakao 또는 Dracula를 선택하면 동봉된 오프라인 VSIX 설치 관리자가 열립니다. 설치를 완료하고 같은 Visual Studio를 다시 여세요. `Themes` 폴더의 독립 테마는 AI 확장 없이도 사용할 수 있습니다.

Claude 검사는 사용자 선택에 따라 로그인 없이 진행했습니다. 실제 계정의 AI 답변, 고객의 제한망 PC, VS2017 Professional 15.7.1의 실제 설치는 별도 확인 대상입니다. Windows 10 1809 이상 또는 Windows 11 x64와 필요한 Visual Studio/.NET 구성요소가 먼저 설치되어 있어야 합니다. 이전 정식 릴리스와 공개 미리보기는 그대로 보존합니다.

설치 결과를 전달할 때는 `RESULT.json`의 상태·오류 문구·AI 도구창 열림 여부만 알려주세요. 암호나 토큰은 보내지 마세요.
