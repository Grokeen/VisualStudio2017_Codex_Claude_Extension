﻿# Visual Studio AI Assistant v0.11.1 설치 묶음

1. 전체 ZIP을 새 폴더에 압축 해제하고 Visual Studio를 닫습니다.
2. InstallAIAssistant.bat를 실행합니다. 여러 IDE가 있으면 설치할 번호를 선택합니다.
3. 버전과 파일 검사를 통과하면 해당 IDE의 공식 설치기가 열립니다. 설치 화면을 따라 진행하세요.
4. Visual Studio를 다시 열어 도구 → AI Assistant를 선택합니다.

VS2017 15.7·15.8에는 VS2017.15.7.AIAssistant-0.11.1.vsix, 15.9 이상에는 VS2017.AIAssistant-0.11.1.vsix를 사용합니다. VS2019/2022에는 각 연도 전용 파일을 사용합니다. 이 도구는 Visual Studio 자체를 업데이트하지 않습니다. Community·Professional·Enterprise를 지원하며 VS2017 15.7 미만과 VS2022 ARM64는 지원하지 않습니다. VS2017 두 패키지를 한 IDE에 함께 설치하지 않습니다.

15.7 전용은 당시 SDK로 별도 빌드했습니다. 실제 IDE 검사는 개발 PC의 VS2017 15.9에서 수행했으며 고객 15.7.1 Professional의 설치·실행 성공은 아직 확인하지 않았습니다.

설치 오류와 진단 전용 명령은 INSTALL_TROUBLESHOOTING.md를 확인하세요. 진단·설치 로그는 로컬 파일에 남기며 자동 전송하지 않습니다. 최종 의존성 확인은 공식 VSIXInstaller에서 수행합니다. SHA256SUMS.txt와 BUNDLE_SHA256SUMS.txt는 파일 손상 검사입니다.

CLI 설치가 필요하면 HowToInstallCLI.md와 output/pdf 안의 기존 PDF를 먼저 확인하세요. InstallCLI.bat는 직접 실행할 때만 CLI 설치를 시작합니다. VSIX 설치는 CLI 로그인과 별도이며 브라우저/Claude 앱의 로그인과 CLI 로그인도 별도입니다.

확장 제거: VS2017 도구 → 확장 및 업데이트 → 설치됨 / VS2019·2022 확장 → 확장 관리 → 설치됨에서 해당 확장을 제거하고 모든 IDE 창을 닫습니다. CLI·계정·대화 데이터는 이 절차에서 삭제하지 않습니다.

테스트 실행기는 GitHub Release에서 별도 제공합니다. 검사는 저장소를 복제한 루트 폴더에서 소스와 개발 도구를 준비한 뒤 실행하세요. 이 설치 묶음에는 검사 소스와 개발 도구를 포함하지 않습니다.

사용 안내: https://github.com/Grokeen/VisualStudio2017_Codex_Claude_Extension/blob/main/docs/USER_GUIDE.md
GitHub Release: https://github.com/Grokeen/VisualStudio2017_Codex_Claude_Extension/releases/tag/v0.11.1