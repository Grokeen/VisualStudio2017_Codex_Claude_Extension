﻿# 오프라인 설치 준비 도구 v0.11.1 / OfflineTools1

이 ZIP은 준비 도구와 Visual Studio 4종 설치 파일입니다. Codex·Claude 실행 파일은 아직 들어 있지 않습니다. 인터넷 PC에서 완성 묶음을 만든 다음 USB로 옮겨 사용하세요. 대상은 Windows x64이며 동봉 Claude는 Windows 10 1809/Server 2019 이상이 필요합니다.

## 인터넷 PC에서 준비

1. 이 ZIP을 새 폴더에 모두 풉니다.
2. 공식 Codex와 Claude 네이티브 CLI가 없다면 온라인용 InstallCLI.bat를 실행해 준비합니다. 이미 설치돼 있으면 이 단계는 건너뜁니다. 로그인은 준비에 필요하지 않습니다.
3. PrepareOfflineSetup.bat를 실행합니다. Codex standalone 전체 런타임과 Claude 본체의 게시자 서명을 확인하고 PreparedOffline-날짜.zip을 만듭니다.
4. 생성된 ZIP 전체와 옆의 .zip.sha256을 승인된 USB 등으로 오프라인 PC에 옮깁니다. CLI 계정·토큰·사용자 프로필은 포함하지 않습니다.

## 오프라인 PC에서 설치

1. 완성된 PreparedOffline ZIP을 로컬 폴더에 모두 풉니다. 이 준비 도구 ZIP만 옮긴 상태에서는 CLI를 설치할 수 없습니다.
2. InstallOfflineCLI.bat를 실행합니다. 로컬 SHA256·PE 구조 확인 뒤 사용자 전용 새 폴더에 CLI 전체 런타임을 복사합니다. 다운로드·CLI 실행·로그인·PATH 변경을 하지 않습니다.
3. InstallAIAssistant.bat를 실행해 해당 Visual Studio용 VSIX를 설치합니다. VS2017 15.7·15.8에는 전용 패키지가 선택됩니다. 필요한 .NET/Visual Studio 핵심 구성 요소는 대상 PC에 미리 설치되어 있어야 합니다.
4. 도구 → AI Assistant → 설정에서 CLI 설치 완료 화면의 Codex/Claude 실행 파일 경로를 지정합니다.
5. 네트워크 연결이 허용되는 시점에 본인 계정으로 공식 로그인과 실제 AI 요청을 확인합니다.

오프라인 PC에서는 온라인용 InstallCLI.bat를 실행하지 마세요. CLI 복사는 기존 CLI·계정·VS 설정을 변경하지 않습니다. 같은 파일이 이미 있으면 재사용하고 내용이 다르면 보존한 채 중단합니다. Windows 7/8.1, x86/ARM64 및 고객의 실제 VS2017 Professional 15.7.1에서 이번 완성 묶음을 실행한 결과는 확인하지 않았습니다.

상세 절차: [OFFLINE_INSTALL.md](OFFLINE_INSTALL.md). 기존 CLI 그림 설명서는 HowToInstallCLI.md와 output/pdf 안에 있습니다. BUNDLE_SHA256SUMS.txt는 전송 손상 검사이며 게시자 서명을 대신하지 않습니다. 공개 도구에는 계정이나 API 키가 없습니다.