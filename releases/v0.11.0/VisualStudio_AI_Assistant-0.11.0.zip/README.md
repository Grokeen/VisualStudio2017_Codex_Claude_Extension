﻿# Visual Studio AI Assistant v0.11.0 설치 묶음

1. Visual Studio를 모두 닫고 사용 중인 IDE에 맞는 VS2017/VS2019/VS2022 파일 한 개를 실행합니다. 여러 IDE를 사용한다면 각각 설치하세요.
2. Visual Studio를 다시 열어 도구 → AI Assistant를 선택합니다.
3. Codex 또는 Claude의 공식 CLI 설치·로그인 상태를 확인한 뒤 요청을 입력합니다. 브라우저/Claude 앱의 로그인과 CLI 로그인은 별도입니다.

CLI 설치가 필요하면 HowToInstallCLI.md와 output/pdf 안의 기존 PDF를 먼저 확인하세요. InstallCLI.bat는 직접 실행할 때만 설치를 시작합니다. 이 압축 파일을 풀거나 VSIX를 설치하는 것만으로 CLI나 계정 로그인을 실행하지 않습니다.

같은 팀의 Claude/Codex를 역할·협업 설정에서 함께 선택할 수 있습니다. 선택한 요청·소스·첨부는 각 서비스로 전송되며 호출별 사용량이 발생합니다. 동료 검토 후 주 담당자가 종합합니다. 실제 Claude 계정·운영 DB/TFVC/운영 배포는 격리 검사와 별도로 확인해야 합니다.

확장 제거: VS2017 도구 → 확장 및 업데이트 → 설치됨 / VS2019·2022 확장 → 확장 관리 → 설치됨에서 해당 확장을 제거하고 모든 IDE 창을 닫습니다. CLI·계정·대화 데이터는 이 절차에서 삭제하지 않습니다.

파일 무결성은 BUNDLE_SHA256SUMS.txt로 확인할 수 있습니다. 테스트 실행기는 GitHub Release에서 별도 제공합니다. 실행기 검사는 GitHub 소스 코드 ZIP을 풀거나 저장소를 복제한 루트 폴더에서 실행하세요. 이 설치 묶음에는 검사 소스와 개발 도구를 포함하지 않습니다.

사용 안내: https://github.com/Grokeen/VisualStudio2017_Codex_Claude_Extension/blob/main/docs/USER_GUIDE.md
GitHub Release: https://github.com/Grokeen/VisualStudio2017_Codex_Claude_Extension/releases/tag/v0.11.0