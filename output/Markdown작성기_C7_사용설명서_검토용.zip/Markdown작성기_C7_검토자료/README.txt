Markdown 작성기 사용 설명서 C7 검토 자료

이 묶음에는 PDF와 동일 내용의 Markdown, 그림 10개가 들어 있습니다. Markdown 파일과 images 폴더의 상대 경로를 유지하세요.

08~09번은 candidate7 제품 DLL에서 별도 STA 프로세스로 렌더한 WPF 컨트롤입니다. Visual Studio 창을 띄우거나 실제 IDE에서 캡처하지 않았습니다. 3개 SKU의 문서 UI 검사는 각각 117/117 통과했고 별도 HTML 후속 감사는 21/21 통과했습니다. 최종 IDE 통합 검증은 별도입니다.

이 자료는 candidate7 기준 검토 개정입니다. 실제 배포 전 최종 패키지와 UI 문구를 다시 대조하세요.
